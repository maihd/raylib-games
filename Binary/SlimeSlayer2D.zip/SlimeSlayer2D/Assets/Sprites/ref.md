Slime: https://rvros.itch.io/pixel-art-animated-slime
Player: https://rvros.itch.io/animated-pixel-hero
Background+Coin: https://trixelized.itch.io/nightfield